import React, { useState,useEffect} from 'react';
import {
  CCard,
  CCardHeader,
  CCardBody
} from '@coreui/react'
import { DocsLink } from 'src/reusable'
import axios from 'axios';
import { DatePicker, Modal,Button, Space, Table} from 'antd';
import 'antd/dist/antd.css';



const Typography = () => {
  const [datas,setDatas] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [myrecord,setMyrecord] = useState({});
  const [tanggal, setTanggal] = useState("");
  const [selectedFile, setSelectedFile] = useState("");
  useEffect(() => {
      var idsponsor = localStorage.getItem("loginid");

    // axios({
    //   // url: "https://primavisiglobalindo.net/demo/conference1/wp-content/plugins/perki/kirimdata.php",
    //   url: "http://localhost/perki/kirimdata.php",
    //   data: payload,
    //   contentType: "application/json",
    //   method: 'POST',
    // })

    // axios.post({
    //   url: "http://localhost/perki/kirimdata.php",
    //   data: {mtd:'ANGGOTA'},
    //   contentType: "application/json",
    //   method: 'POST',
    //   }).then((data) => {
    //       console.log(data);
    //   }).catch(function (error) {
    //   });


      axios({
        url: "https://primavisiglobalindo.net/demo/conference1/wp-content/plugins/perki/kirimdata.php",
        // url: "http://localhost/perki/kirimdata.php",
        data: {mtd:'ANGGOTA',idsponsor:idsponsor},
        contentType: "application/json",
        method: 'POST',
      })
        .then((data) => {
          // var temp = data.data;
          console.log(data.data);
          // var temp = [];
          // for (const x of data.data)
          // {
          //   console.log(x.firstname);
          //   console.log(x.lastname);
          //   temp.push({
          //     firstname:x.firstname,
          //     lastname:x.lastname
          //   })
          // }

          setDatas(data.data);
          // console.log(JSON.parse(data.data));
            // localStorage.setItem("loginid",temp.data);

            //   history.push('/dashboard');

        })
        .catch(() => {
          console.log('Internal server error');
        });
  // loadkategori();
}, []);

const onFileChange = event => {

  // Update the state
  // this.setState({ selectedFile: event.target.files[0] });
  setSelectedFile(event.target.files[0]);

};


const handleOk = () => {
  setIsModalVisible(false);
};

const handleCancel = () => {
  setIsModalVisible(false);
};


const upload = (value) => {
  setIsModalVisible(true);setMyrecord(value);
}

const columns = [
  {
    title: "firstname",
    dataIndex: "firstname",
    key: "firstname"
  },
  {
    title: "profession",
    dataIndex: "profession",
    key: "profession"
  },
  {
    title: "mobilephone",
    dataIndex: "mobilephone",
    key: "mobilephone"
  },
  {
    title: "payment",
    dataIndex: "payment",
    key: "payment"
  },
  {
    title: "total",
    dataIndex: "total",
    key: "total"
  },
  {
    title: "pilih",
    dataIndex: "pilih",
    key: "pilih"
  },
  {
    title: "simposium",
    dataIndex: "simposium",
    key: "simposium"
  },
  {
    title: "workshop",
    dataIndex: "workshop",
    key: "workshop"
  },
  {
    title: "package",
    dataIndex: "package",
    key: "package"
  },
//   {
//     title: "Upload",
//     dataIndex: "file",
//     key: "file",
//     render: (text, record) => (
//       <div>
// {(record.file ==="" || record.file===undefined)?
// <Button onClick={()=>upload(record)} >Upload</Button>
// :
// "PAID"
// }

//       </div>

//     ),
// },
];
  // {
  //   title: "firstname",
  //   dataIndex: "firstname",
  //   key: "firstname",
  // },
  // {
  //   title: "firstname",
  //   dataIndex: "firstname",
  //   key: "firstname",
  // },
  // {
  //   title: "firstname",
  //   dataIndex: "firstname",
  //   key: "firstname",
  // },


  return (
    <>
      <CCard>
        <CCardHeader>
          Sponsor
          {/* <DocsLink href="https://coreui.io/docs/content/typography/"/> */}
        </CCardHeader>
        <CCardBody>
        <a href="/demo/conference1/wp-content/plugins/perki/build/#/theme/perki"><Button type="primary" style={{marginBottom:"20px"}}>Add Participant</Button></a>
        <Table columns={columns} dataSource={datas} />
        <div>Total GP, Nurse or Paramedic, Medical Student (for claim bonus)</div>
        <div>Total Simposium : <b>{datas.filter(ch => ch.pilih == "simposium" && (ch.profession=="GP" || ch.profession=="Medical Student" || ch.profession=="Nurse or Paramedics") ).length}</b></div>
        <div>Total Workshop : <b>{datas.filter(ch => ch.pilih == "workshop" && (ch.profession=="GP" || ch.profession=="Medical Student" || ch.profession=="Nurse or Paramedics")).length}</b></div>
        <div>Total Package : <b>{datas.filter(ch => ch.pilih == "package" && (ch.profession=="GP" || ch.profession=="Medical Student" || ch.profession=="Nurse or Paramedics")).length}</b></div>
        <div>Bonus 1 : 10 get 1 for GP Nurse Medical Student take workshop / simposium, current total : <b>{datas.filter(ch => (ch.pilih == "simposium" || ch.pilih == "workshop") && (ch.profession=="GP" || ch.profession=="Medical Student" || ch.profession=="Nurse or Paramedics") ).length}</b></div>
        <div>Bonus 2 : 5 get 1 for GP Nurse Medical Student take package, current total <b>{datas.filter(ch => (ch.pilih == "package") && (ch.profession=="GP" || ch.profession=="Medical Student" || ch.profession=="Nurse or Paramedics") ).length}</b> </div>

        {/* <div>data={datas.filter(ch => ch.pilih == "simposium").length}</div> */}
        {/* }

        {kota.filter(character => character.propinsi === propinsiselect).map((item) =>(

<Option value={item.kota}>{item.kota}</Option>

          ))} */}
        </CCardBody>
      </CCard>
      <Modal title="Upload bukti" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel}>
        <p>First Nama : {myrecord.firstname}</p>
        <p>Last Name : {myrecord.lastname}</p>
        <p>Total : {myrecord.total}</p>
        <p>Tanggal : <DatePicker onChange={(date, dateString)=>setTanggal(dateString)} /></p>
        <p>Upload : <input type="file" onChange={onFileChange} multiple /></p>
      </Modal>    </>
  )
}

export default Typography
